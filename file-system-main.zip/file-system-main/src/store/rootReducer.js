import { combineReducers } from 'redux';
import fileSystem from './fileSystemReducer.js';

export default combineReducers({ fileSystem });
